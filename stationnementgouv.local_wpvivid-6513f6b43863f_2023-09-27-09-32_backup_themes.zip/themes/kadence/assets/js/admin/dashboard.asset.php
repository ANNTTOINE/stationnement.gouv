<?php return array('dependencies' => array('wp-components', 'wp-element', 'wp-i18n'), 'version' => 'b9804d9d06162dc644d6');
