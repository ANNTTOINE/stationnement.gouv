<?php
/**
 * Template part for displaying a post's excerpt.
 *
 * @package kadence
 */

namespace Kadence;

?>
<div class="title-entry-excerpt">
	<?php the_excerpt(); ?>
</div><!-- .title-entry-excerpt -->
